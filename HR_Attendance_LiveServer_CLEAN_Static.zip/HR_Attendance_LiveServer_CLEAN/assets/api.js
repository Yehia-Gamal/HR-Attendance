import { seedDatabase } from "./database.js";

const STORAGE_KEY = "hr-attendance.local-db.v3";
const SESSION_KEY = "hr-attendance.session-user";

const clone = (value) => JSON.parse(JSON.stringify(value));

function loadDb() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (!saved) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(seedDatabase));
    return clone(seedDatabase);
  }
  return JSON.parse(saved);
}

function saveDb(db) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
}

function makeId(prefix) {
  return `${prefix}-${crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36)}`;
}

function findById(items, id) {
  return items.find((item) => item.id === id) || null;
}

function enrichEmployee(db, employee) {
  const user = db.users.find((item) => item.employeeId === employee.id) || findById(db.users, employee.userId);
  return {
    ...employee,
    role: findById(db.roles, employee.roleId),
    branch: findById(db.branches, employee.branchId),
    department: findById(db.departments, employee.departmentId),
    governorate: findById(db.governorates, employee.governorateId),
    complex: findById(db.complexes, employee.complexId),
    manager: findById(db.employees, employee.managerEmployeeId),
    user: user || null,
  };
}

function enrichUser(db, user) {
  const employee = findById(db.employees, user.employeeId);
  return {
    ...user,
    employee: employee ? enrichEmployee(db, employee) : null,
    role: findById(db.roles, user.roleId),
    branch: findById(db.branches, user.branchId),
    department: findById(db.departments, user.departmentId),
    governorate: findById(db.governorates, user.governorateId),
    complex: findById(db.complexes, user.complexId),
  };
}

function enrichByEmployee(db, item) {
  const employee = findById(db.employees, item.employeeId);
  return { ...item, employee: employee ? enrichEmployee(db, employee) : null };
}

function distanceMeters(a, b) {
  if (![a?.latitude, a?.longitude, b?.latitude, b?.longitude].every((value) => Number.isFinite(Number(value)))) return null;
  const toRad = (value) => (Number(value) * Math.PI) / 180;
  const radius = 6371000;
  const dLat = toRad(b.latitude - a.latitude);
  const dLng = toRad(b.longitude - a.longitude);
  const lat1 = toRad(a.latitude);
  const lat2 = toRad(b.latitude);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return Math.round(2 * radius * Math.asin(Math.sqrt(h)));
}

function activeMissionForEmployee(db, employeeId, at = new Date()) {
  return db.missions.find((mission) => {
    if (mission.employeeId !== employeeId) return false;
    if (!["APPROVED", "IN_PROGRESS"].includes(mission.status)) return false;
    const start = mission.plannedStart ? new Date(mission.plannedStart) : null;
    const end = mission.plannedEnd ? new Date(mission.plannedEnd) : null;
    return (!start || at >= start) && (!end || at <= end);
  }) || null;
}

function evaluateAttendance(db, body, eventType) {
  const employee = findById(db.employees, body.employeeId);
  const branch = employee ? findById(db.branches, employee.branchId) : null;
  const currentLocation = Number.isFinite(Number(body.latitude)) && Number.isFinite(Number(body.longitude))
    ? { latitude: Number(body.latitude), longitude: Number(body.longitude) }
    : null;
  const activeMission = activeMissionForEmployee(db, body.employeeId);
  const verificationStatus = body.verificationStatus || "not_checked";
  const riskFlags = [];
  let geofenceStatus = "unknown";
  let distanceFromBranchMeters = null;
  let requiresReview = false;
  let primaryStatus = eventType === "CHECK_OUT" ? "CHECK_OUT" : "PRESENT";

  if (verificationStatus !== "verified") {
    requiresReview = true;
    riskFlags.push("passkey_missing");
  }

  if (!currentLocation) {
    geofenceStatus = body.locationPermission === "denied" ? "permission_denied" : "location_unavailable";
    requiresReview = true;
    riskFlags.push(body.locationPermission === "denied" ? "location_denied" : "location_unknown");
  } else if (!branch) {
    geofenceStatus = "branch_unknown";
    requiresReview = true;
    riskFlags.push("branch_unknown");
  } else {
    distanceFromBranchMeters = distanceMeters(currentLocation, branch);
    if (distanceFromBranchMeters != null && distanceFromBranchMeters <= Number(branch.geofenceRadiusMeters || 200)) {
      geofenceStatus = "inside_branch";
    } else if (activeMission) {
      geofenceStatus = "inside_mission";
      primaryStatus = "MISSION";
    } else {
      geofenceStatus = "outside_branch";
      requiresReview = true;
      riskFlags.push("geofence_miss");
      primaryStatus = eventType === "CHECK_OUT" ? "CHECKOUT_REVIEW" : "PRESENT_REVIEW";
    }
  }

  if (eventType === "CHECK_OUT" && primaryStatus !== "MISSION" && primaryStatus !== "CHECKOUT_REVIEW") {
    primaryStatus = "CHECK_OUT";
  }

  return {
    type: primaryStatus,
    verificationStatus,
    geofenceStatus,
    requiresReview,
    riskFlags,
    distanceFromBranchMeters,
    latitude: currentLocation?.latitude ?? null,
    longitude: currentLocation?.longitude ?? null,
    branchId: branch?.id || "",
    missionId: activeMission?.id || "",
    notes: body.notes || "",
  };
}

function visibleEmployees(db) {
  return db.employees.filter((employee) => !employee.isDeleted).map((employee) => enrichEmployee(db, employee));
}

function applyEmployeePayload(db, target, body) {
  const branch = findById(db.branches, body.branchId);
  Object.assign(target, {
    employeeCode: body.employeeCode?.trim() || target.employeeCode,
    fullName: body.fullName?.trim() || target.fullName,
    phone: body.phone?.trim() || "",
    email: body.email?.trim() || "",
    photoUrl: body.photoUrl || target.photoUrl || "",
    jobTitle: body.jobTitle?.trim() || "",
    roleId: body.roleId || db.roles.at(-1)?.id,
    branchId: body.branchId || db.branches[0]?.id,
    departmentId: body.departmentId || db.departments[0]?.id,
    governorateId: body.governorateId || branch?.governorateId || db.governorates[0]?.id,
    complexId: body.complexId || branch?.complexId || db.complexes[0]?.id,
    managerEmployeeId: body.managerEmployeeId || "",
    status: body.status || "ACTIVE",
  });
  return target;
}

function dashboard(db) {
  const employees = db.employees.filter((employee) => !employee.isDeleted);
  const today = new Date().toISOString().slice(0, 10);
  const todayEvents = db.attendanceEvents.filter((event) => event.eventAt.startsWith(today) || event.eventAt.startsWith("2026-04-26"));
  const activeEmployees = employees.filter((employee) => employee.status === "ACTIVE").length;
  const present = todayEvents.filter((event) => ["PRESENT", "LATE", "MISSION"].includes(event.type)).length;
  const late = todayEvents.filter((event) => event.type === "LATE").length;
  const absent = todayEvents.filter((event) => event.type === "ABSENT").length;
  const departments = db.departments.map((department) => ({
    label: department.name,
    present: todayEvents.filter((event) => findById(db.employees, event.employeeId)?.departmentId === department.id && ["PRESENT", "LATE", "MISSION"].includes(event.type)).length,
    late: todayEvents.filter((event) => findById(db.employees, event.employeeId)?.departmentId === department.id && event.type === "LATE").length,
    mission: todayEvents.filter((event) => findById(db.employees, event.employeeId)?.departmentId === department.id && event.type === "MISSION").length,
  }));

  return {
    metrics: [
      { label: "الموظفون النشطون", value: activeEmployees, helper: `${employees.length} ملف موظف` },
      { label: "حضور اليوم", value: present, helper: "حضور وتأخير ومأموريات" },
      { label: "طلبات مفتوحة", value: db.leaves.filter((item) => item.status === "PENDING").length + db.missions.filter((item) => item.status === "PENDING").length, helper: "إجازات ومأموريات" },
      { label: "مستخدمون مفعلون", value: db.users.filter((user) => user.status === "ACTIVE").length, helper: "حسابات دخول" },
    ],
    attendanceBreakdown: [
      { label: "حاضر", value: todayEvents.filter((event) => event.type === "PRESENT").length },
      { label: "متأخر", value: late },
      { label: "مأمورية", value: todayEvents.filter((event) => event.type === "MISSION").length },
      { label: "غائب", value: absent },
    ],
    attendanceTrends: departments,
    latestEvents: db.attendanceEvents.map((event) => enrichByEmployee(db, event)).sort((a, b) => new Date(b.eventAt) - new Date(a.eventAt)).slice(0, 6),
  };
}

async function ok(value) {
  return clone(value);
}

export function unwrap(payload) {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.items)) return payload.items;
  if (payload?.data != null) return payload.data;
  return payload;
}

export const endpoints = {
  me: async () => {
    const db = loadDb();
    const userId = sessionStorage.getItem(SESSION_KEY);
    const user = db.users.find((item) => item.id === userId && item.status === "ACTIVE");
    return ok(user ? enrichUser(db, user) : null);
  },
  login: async (identifier, password) => {
    const db = loadDb();
    const user = db.users.find((item) => item.status === "ACTIVE" && [item.email, item.name].includes(identifier) && item.password === password);
    if (!user) throw new Error("بيانات الدخول غير صحيحة أو الحساب غير مفعل.");
    user.lastLoginAt = new Date().toISOString();
    saveDb(db);
    sessionStorage.setItem(SESSION_KEY, user.id);
    return ok(enrichUser(db, user));
  },
  logout: async () => {
    sessionStorage.removeItem(SESSION_KEY);
    return ok({ ok: true });
  },
  dashboard: async () => ok(dashboard(loadDb())),
  health: async () => ok({ app: "Live Server Static Web", database: { mode: "localStorage", connected: true }, authEnforced: true }),
  employees: async () => ok(visibleEmployees(loadDb())),
  employee: async (employeeId) => {
    const db = loadDb();
    const employee = findById(db.employees, employeeId);
    if (!employee || employee.isDeleted) throw new Error("لم يتم العثور على الموظف.");
    return ok({
      ...enrichEmployee(db, employee),
      attendanceEvents: db.attendanceEvents.filter((item) => item.employeeId === employeeId).sort((a, b) => new Date(b.eventAt) - new Date(a.eventAt)),
      missions: db.missions.filter((item) => item.employeeId === employeeId),
      leaves: db.leaves.filter((item) => item.employeeId === employeeId),
    });
  },
  createEmployee: async (body) => {
    const db = loadDb();
    if (db.employees.some((employee) => !employee.isDeleted && employee.employeeCode === body.employeeCode)) throw new Error("كود الموظف مستخدم بالفعل.");
    const employee = applyEmployeePayload(db, { id: makeId("emp"), isDeleted: false, hireDate: new Date().toISOString().slice(0, 10), userId: "" }, body);
    db.employees.unshift(employee);
    if (body.createUser === "on") {
      const user = createUserRecord(db, { ...body, employeeId: employee.id, name: employee.fullName, password: body.password || "Temp@123" });
      employee.userId = user.id;
    }
    saveDb(db);
    return ok(enrichEmployee(db, employee));
  },
  updateEmployee: async (employeeId, body) => {
    const db = loadDb();
    const employee = findById(db.employees, employeeId);
    if (!employee) throw new Error("لم يتم العثور على الموظف.");
    applyEmployeePayload(db, employee, body);
    saveDb(db);
    return ok(enrichEmployee(db, employee));
  },
  setEmployeeStatus: async (employeeId, status) => {
    const db = loadDb();
    const employee = findById(db.employees, employeeId);
    if (!employee) throw new Error("لم يتم العثور على الموظف.");
    employee.status = status;
    const user = db.users.find((item) => item.employeeId === employeeId);
    if (user && ["INACTIVE", "SUSPENDED"].includes(status)) user.status = "DISABLED";
    saveDb(db);
    return ok(enrichEmployee(db, employee));
  },
  deleteEmployee: async (employeeId) => {
    const db = loadDb();
    const employee = findById(db.employees, employeeId);
    if (!employee) throw new Error("لم يتم العثور على الموظف.");
    employee.isDeleted = true;
    employee.status = "INACTIVE";
    const user = db.users.find((item) => item.employeeId === employeeId);
    if (user) user.status = "DISABLED";
    saveDb(db);
    return ok({ ok: true });
  },
  users: async () => ok(loadDb().users.map((user) => enrichUser(loadDb(), user))),
  createUser: async (body) => {
    const db = loadDb();
    const user = createUserRecord(db, body);
    const employee = findById(db.employees, user.employeeId);
    if (employee) employee.userId = user.id;
    saveDb(db);
    return ok(enrichUser(db, user));
  },
  updateUser: async (userId, body) => {
    const db = loadDb();
    const user = findById(db.users, userId);
    if (!user) throw new Error("لم يتم العثور على المستخدم.");
    Object.assign(user, {
      name: body.name || user.name,
      email: body.email || user.email,
      roleId: body.roleId || user.roleId,
      employeeId: body.employeeId || "",
      branchId: body.branchId || "",
      departmentId: body.departmentId || "",
      governorateId: body.governorateId || "",
      complexId: body.complexId || "",
      status: body.status || user.status,
      temporaryPassword: body.temporaryPassword === "on" || body.temporaryPassword === true,
      passkeyEnabled: body.passkeyEnabled === "on" || body.passkeyEnabled === true,
    });
    if (body.password) user.password = body.password;
    const employee = findById(db.employees, user.employeeId);
    if (employee) employee.userId = user.id;
    saveDb(db);
    return ok(enrichUser(db, user));
  },
  setUserStatus: async (userId, status) => {
    const db = loadDb();
    const user = findById(db.users, userId);
    if (!user) throw new Error("لم يتم العثور على المستخدم.");
    user.status = status;
    saveDb(db);
    return ok(enrichUser(db, user));
  },
  attendanceEvents: async () => {
    const db = loadDb();
    return ok(db.attendanceEvents.map((event) => enrichByEmployee(db, event)).sort((a, b) => new Date(b.eventAt) - new Date(a.eventAt)));
  },
  checkIn: async (body) => {
    const db = loadDb();
    const evaluation = evaluateAttendance(db, body, "PRESENT");
    db.attendanceEvents.unshift({ id: makeId("att"), employeeId: body.employeeId, eventAt: new Date().toISOString(), source: "Live Server", ...evaluation });
    saveDb(db);
    return ok({ ok: true, evaluation });
  },
  checkOut: async (body) => {
    const db = loadDb();
    const evaluation = evaluateAttendance(db, body, "CHECK_OUT");
    db.attendanceEvents.unshift({ id: makeId("att"), employeeId: body.employeeId, eventAt: new Date().toISOString(), source: "Live Server", ...evaluation });
    saveDb(db);
    return ok({ ok: true, evaluation });
  },
  missions: async () => {
    const db = loadDb();
    return ok(db.missions.map((mission) => enrichByEmployee(db, mission)));
  },
  createMission: async (body) => {
    const db = loadDb();
    db.missions.unshift({ id: makeId("mis"), employeeId: body.employeeId || db.employees[0]?.id, title: body.title, destinationName: body.destinationName || "", plannedStart: body.plannedStart || "", plannedEnd: body.plannedEnd || "", status: "PENDING", createdAt: new Date().toISOString() });
    saveDb(db);
    return ok({ ok: true });
  },
  updateMission: async (missionId, action) => {
    const db = loadDb();
    const mission = findById(db.missions, missionId);
    if (mission) mission.status = action === "complete" ? "COMPLETED" : "APPROVED";
    saveDb(db);
    return ok(mission);
  },
  leaves: async () => {
    const db = loadDb();
    return ok(db.leaves.map((leave) => enrichByEmployee(db, leave)));
  },
  createLeave: async (body) => {
    const db = loadDb();
    db.leaves.unshift({ id: makeId("lv"), employeeId: body.employeeId || db.employees[0]?.id, leaveType: { name: body.leaveType || "اعتيادية" }, startDate: body.startDate, endDate: body.endDate, reason: body.reason, status: "PENDING", createdAt: new Date().toISOString() });
    saveDb(db);
    return ok({ ok: true });
  },
  updateLeave: async (leaveId, action) => {
    const db = loadDb();
    const leave = findById(db.leaves, leaveId);
    if (leave) leave.status = action === "reject" ? "REJECTED" : "APPROVED";
    saveDb(db);
    return ok(leave);
  },
  exceptions: async () => ok(loadDb().exceptions.map((item) => enrichByEmployee(loadDb(), item))),
  notifications: async () => ok(loadDb().notifications),
  reports: async () => ok({ jobs: loadDb().reports }),
  createReport: async (body) => {
    const db = loadDb();
    db.reports.unshift({ id: makeId("rep"), title: body.title, reportKey: body.reportKey || "attendance", format: body.format || "csv", status: "COMPLETED", createdAt: new Date().toISOString() });
    saveDb(db);
    return ok({ ok: true });
  },
  settings: async () => ok(loadDb().settings),
  kpi: async () => {
    const db = loadDb();
    const employees = db.employees.filter((employee) => !employee.isDeleted);
    return ok([
      { id: "kpi-001", name: "نسبة الحسابات المرتبطة بموظفين", status: `${Math.round((db.users.filter((user) => user.employeeId).length / Math.max(1, employees.length)) * 100)}%`, createdAt: new Date().toISOString() },
      { id: "kpi-002", name: "نسبة الموظفين النشطين", status: `${Math.round((employees.filter((employee) => employee.status === "ACTIVE").length / Math.max(1, employees.length)) * 100)}%`, createdAt: new Date().toISOString() },
      { id: "kpi-003", name: "طلبات مفتوحة", status: db.leaves.filter((item) => item.status === "PENDING").length + db.missions.filter((item) => item.status === "PENDING").length, createdAt: new Date().toISOString() },
    ]);
  },
  locations: async () => ok(loadDb().locations.map((item) => enrichByEmployee(loadDb(), item))),
  queue: async () => ok({ enabled: false }),
  roles: async () => ok(loadDb().roles),
  branches: async () => ok(loadDb().branches),
  departments: async () => ok(loadDb().departments),
  governorates: async () => ok(loadDb().governorates),
  complexes: async () => ok(loadDb().complexes),
  reset: async () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(seedDatabase));
    return ok({ ok: true });
  },
};

function createUserRecord(db, body) {
  if (db.users.some((user) => user.email === body.email)) throw new Error("البريد الإلكتروني مستخدم بالفعل.");
  const employee = findById(db.employees, body.employeeId);
  const user = {
    id: makeId("u"),
    employeeId: body.employeeId || "",
    name: body.name || employee?.fullName || body.email,
    email: body.email,
    password: body.password || "Temp@123",
    roleId: body.roleId || employee?.roleId || db.roles.at(-1)?.id,
    branchId: body.branchId || employee?.branchId || "",
    departmentId: body.departmentId || employee?.departmentId || "",
    governorateId: body.governorateId || employee?.governorateId || "",
    complexId: body.complexId || employee?.complexId || "",
    status: body.status || "ACTIVE",
    temporaryPassword: true,
    passkeyEnabled: false,
    lastLoginAt: "",
  };
  db.users.unshift(user);
  return user;
}
