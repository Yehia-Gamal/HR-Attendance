import { endpoints, unwrap } from "./api.js";

const app = document.querySelector("#app");
const state = {
  route: location.hash.replace("#", "") || "dashboard",
  user: null,
  message: "",
  error: "",
};

const navGroups = [
  ["الرئيسية", [["dashboard", "لوحة المتابعة"], ["attendance", "الحضور"]]],
  ["الأفراد", [["employees", "الأشخاص والموظفون"], ["users", "المستخدمون"]]],
  ["التشغيل", [["missions", "المأموريات"], ["leaves", "الإجازات"], ["locations", "المواقع"]]],
  ["المتابعة", [["kpi", "مؤشرات الأداء"], ["notifications", "الإشعارات"], ["reports", "التقارير"], ["settings", "الإعدادات"]]],
];

window.addEventListener("hashchange", () => {
  state.route = location.hash.replace("#", "") || "dashboard";
  render();
});

function setMessage(message, error = "") {
  state.message = message;
  state.error = error;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function date(value) {
  if (!value) return "-";
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? String(value) : parsed.toLocaleString("ar-EG");
}

function statusLabel(value) {
  return {
    ACTIVE: "نشط",
    INACTIVE: "غير مفعل",
    SUSPENDED: "موقوف",
    ON_LEAVE: "إجازة",
    DISABLED: "معطل",
    PRESENT: "حضور",
    PRESENT_REVIEW: "حضور للمراجعة",
    LATE: "تأخير",
    ABSENT: "غياب",
    MISSION: "مأمورية",
    CHECK_OUT: "انصراف",
    CHECKOUT_REVIEW: "انصراف للمراجعة",
    verified: "تحقق ناجح",
    not_checked: "لم يتم التحقق",
    failed: "فشل التحقق",
    inside_branch: "داخل الفرع",
    outside_branch: "خارج الفرع",
    inside_mission: "داخل مأمورية",
    permission_denied: "الموقع مرفوض",
    location_unavailable: "الموقع غير متاح",
    branch_unknown: "فرع غير معروف",
    unknown: "غير معروف",
    passkey_missing: "تحقق مفقود",
    location_denied: "رفض الموقع",
    location_unknown: "موقع غير معروف",
    geofence_miss: "خارج النطاق",
    APPROVED: "معتمد",
    COMPLETED: "مكتمل",
    PENDING: "قيد المراجعة",
    REJECTED: "مرفوض",
    READ: "مقروء",
    UNREAD: "جديد",
    VISITED: "تمت الزيارة",
  }[value] || value || "-";
}

function badge(value) {
  return `<span class="status ${escapeHtml(value)}">${escapeHtml(statusLabel(value))}</span>`;
}

function initials(name) {
  return String(name || "?").trim().split(/\s+/).slice(0, 2).map((part) => part[0]).join("");
}

function avatar(person, size = "") {
  if (person?.photoUrl) return `<img class="avatar ${size}" src="${escapeHtml(person.photoUrl)}" alt="${escapeHtml(person.fullName || person.name)}" />`;
  return `<span class="avatar fallback ${size}">${escapeHtml(initials(person?.fullName || person?.name))}</span>`;
}

function routeKey() {
  return state.route.split("?")[0];
}

function routeParams() {
  return new URLSearchParams(state.route.split("?")[1] || "");
}

function shell(content, title, description = "") {
  const current = routeKey();
  app.innerHTML = `
    <div class="app-shell">
      <aside class="sidebar">
        <div class="brand">
          <img src="./ahla-shabab-logo.png" alt="" onerror="this.style.display='none'" />
          <div>
            <strong>نظام الحضور</strong>
            <span>إدارة أفراد وتشغيل</span>
          </div>
        </div>
        <nav class="nav">
          ${navGroups.map(([group, routes]) => `
            <section class="nav-group">
              <p>${escapeHtml(group)}</p>
              ${routes.map(([key, label]) => `<button class="${current === key ? "is-active" : ""}" data-route="${key}">${escapeHtml(label)}</button>`).join("")}
            </section>
          `).join("")}
        </nav>
      </aside>
      <main class="main">
        <header class="topbar">
          <div>
            <h1>${escapeHtml(title)}</h1>
            <p>${escapeHtml(description)}</p>
          </div>
          <div class="toolbar">
            <span class="user-chip">${avatar(state.user?.employee || state.user, "tiny")} ${escapeHtml(state.user?.name || "مستخدم")}</span>
            <button class="button ghost" data-action="refresh">تحديث</button>
            <button class="button ghost" data-action="reset">استرجاع البيانات</button>
            <button class="button danger" data-action="logout">خروج</button>
          </div>
        </header>
        ${state.message ? `<div class="message">${escapeHtml(state.message)}</div>` : ""}
        ${state.error ? `<div class="message error">${escapeHtml(state.error)}</div>` : ""}
        ${content}
      </main>
    </div>
  `;

  app.querySelectorAll("[data-route]").forEach((button) => button.addEventListener("click", () => (location.hash = button.dataset.route)));
  app.querySelector('[data-action="refresh"]')?.addEventListener("click", render);
  app.querySelector('[data-action="reset"]')?.addEventListener("click", async () => {
    await endpoints.reset();
    setMessage("تم استرجاع بيانات التشغيل الأولية.", "");
    render();
  });
  app.querySelector('[data-action="logout"]')?.addEventListener("click", async () => {
    await endpoints.logout();
    state.user = null;
    renderLogin();
  });
}

function table(headers, rows) {
  return `
    <div class="table-wrap">
      <table>
        <thead><tr>${headers.map((item) => `<th>${escapeHtml(item)}</th>`).join("")}</tr></thead>
        <tbody>${rows.length ? rows.join("") : `<tr><td colspan="${headers.length}" class="empty">لا توجد بيانات مطابقة</td></tr>`}</tbody>
      </table>
    </div>
  `;
}

function optionList(items, selected = "", empty = "") {
  return `${empty ? `<option value="">${escapeHtml(empty)}</option>` : ""}${items.map((item) => `<option value="${escapeHtml(item.id || item.name)}" ${selected === (item.id || item.name) ? "selected" : ""}>${escapeHtml(item.name)}</option>`).join("")}`;
}

function readForm(form) {
  return Object.fromEntries(new FormData(form));
}

async function getBrowserLocation() {
  if (!navigator.geolocation) return { locationPermission: "unavailable" };
  return await new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (position) => resolve({
        locationPermission: "granted",
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracy: position.coords.accuracy,
      }),
      (error) => resolve({
        locationPermission: error.code === error.PERMISSION_DENIED ? "denied" : "unknown",
      }),
      { enableHighAccuracy: true, timeout: 7000, maximumAge: 60000 },
    );
  });
}

async function readPhoto(input) {
  const file = input?.files?.[0];
  if (!file) return "";
  if (file.size > 700 * 1024) throw new Error("الصورة كبيرة. الحد الحالي 700KB لتناسب التخزين المحلي.");
  return await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

async function referenceData() {
  const [roles, branches, departments, governorates, complexes, employees] = await Promise.all([
    endpoints.roles(),
    endpoints.branches(),
    endpoints.departments(),
    endpoints.governorates(),
    endpoints.complexes(),
    endpoints.employees(),
  ]);
  return { roles, branches, departments, governorates, complexes, employees };
}

async function renderLogin() {
  app.innerHTML = `
    <div class="login-screen">
      <form class="login-panel" id="login-form">
        <div class="login-mark">HR</div>
        <h1>تسجيل الدخول</h1>
        <p>نسخة تشغيل محلية ببيانات CRUD محفوظة داخل المتصفح.</p>
        <div class="message compact">admin@company.local / admin123</div>
        ${state.error ? `<div class="message error">${escapeHtml(state.error)}</div>` : ""}
        <label>البريد أو الاسم<input name="identifier" value="admin@company.local" autocomplete="username" required /></label>
        <label>كلمة المرور<input name="password" type="password" value="admin123" autocomplete="current-password" required /></label>
        <button class="button primary full" type="submit">دخول</button>
      </form>
    </div>
  `;
  app.querySelector("#login-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const values = readForm(event.currentTarget);
      state.user = unwrap(await endpoints.login(values.identifier, values.password));
      setMessage("تم تسجيل الدخول.", "");
      render();
    } catch (error) {
      setMessage("", error.message);
      renderLogin();
    }
  });
}

async function renderDashboard() {
  const dashboard = unwrap(await endpoints.dashboard());
  const max = Math.max(1, ...dashboard.attendanceTrends.map((item) => Number(item.present || 0) + Number(item.late || 0) + Number(item.mission || 0)));
  shell(
    `<section class="grid">
      ${dashboard.metrics.map((metric) => `<article class="metric"><span>${escapeHtml(metric.label)}</span><strong>${escapeHtml(metric.value)}</strong><small>${escapeHtml(metric.helper || "")}</small></article>`).join("")}
      <article class="panel span-7">
        <div class="panel-head"><h2>توزيع الحضور حسب القسم</h2><span>اليوم</span></div>
        <div class="chart">${dashboard.attendanceTrends.map((item) => `<div class="bar"><div class="bar-fill" style="height:${((Number(item.present || 0) + Number(item.late || 0) + Number(item.mission || 0)) / max) * 150}px"></div><span>${escapeHtml(item.label)}</span></div>`).join("")}</div>
      </article>
      <article class="panel span-5">
        <div class="panel-head"><h2>ملخص اليوم</h2><span>حضور</span></div>
        ${table(["الحالة", "العدد"], dashboard.attendanceBreakdown.map((item) => `<tr><td>${escapeHtml(item.label)}</td><td><strong>${escapeHtml(item.value)}</strong></td></tr>`))}
      </article>
      <article class="panel">
        <div class="panel-head"><h2>آخر أحداث الحضور</h2><button class="button ghost" data-route="attendance">فتح الحضور</button></div>
        ${table(["الموظف", "النوع", "الوقت", "المصدر"], dashboard.latestEvents.map((event) => `<tr><td class="person-cell">${avatar(event.employee, "tiny")}<span>${escapeHtml(event.employee?.fullName || event.employeeId)}</span></td><td>${badge(event.type)}</td><td>${date(event.eventAt)}</td><td>${escapeHtml(event.source)}</td></tr>`))}
      </article>
    </section>`,
    "لوحة المتابعة",
    "نظرة تشغيلية مركزة على الأشخاص والحضور والطلبات المفتوحة.",
  );
}

function employeeFilters(ref) {
  return `
    <form class="filters" id="employee-filters">
      <input name="q" placeholder="بحث بالاسم أو الهاتف أو البريد" />
      <select name="roleId">${optionList(ref.roles, "", "كل الأدوار")}</select>
      <select name="departmentId">${optionList(ref.departments, "", "كل الأقسام")}</select>
      <select name="branchId">${optionList(ref.branches, "", "كل الفروع")}</select>
      <select name="governorateId">${optionList(ref.governorates, "", "كل المحافظات")}</select>
      <select name="complexId">${optionList(ref.complexes, "", "كل المجمعات")}</select>
      <select name="status">${optionList([{ id: "ACTIVE", name: "نشط" }, { id: "SUSPENDED", name: "موقوف" }, { id: "ON_LEAVE", name: "إجازة" }, { id: "INACTIVE", name: "غير مفعل" }], "", "كل الحالات")}</select>
    </form>`;
}

function filterEmployees(employees) {
  const values = readForm(app.querySelector("#employee-filters"));
  const q = (values.q || "").trim().toLowerCase();
  return employees.filter((employee) => {
    const text = [employee.fullName, employee.phone, employee.email, employee.employeeCode].join(" ").toLowerCase();
    return (!q || text.includes(q))
      && (!values.roleId || employee.roleId === values.roleId)
      && (!values.departmentId || employee.departmentId === values.departmentId)
      && (!values.branchId || employee.branchId === values.branchId)
      && (!values.governorateId || employee.governorateId === values.governorateId)
      && (!values.complexId || employee.complexId === values.complexId)
      && (!values.status || employee.status === values.status);
  });
}

async function renderEmployees() {
  const [employees, ref] = await Promise.all([endpoints.employees().then(unwrap), referenceData()]);
  shell(
    `<section class="stack">
      <article class="panel">
        <div class="panel-head">
          <div><h2>قائمة الأشخاص والموظفين</h2><p>إدارة ملفات الموظفين، الصور، الربط بالمستخدمين، والحالة التشغيلية.</p></div>
          <button class="button primary" data-action="new-employee">إضافة موظف</button>
        </div>
        ${employeeFilters(ref)}
        <div id="employees-list" class="people-grid"></div>
      </article>
      <article id="employee-editor" class="panel hidden"></article>
    </section>`,
    "الأشخاص والموظفون",
    "ملفات كاملة قابلة للإضافة والتعديل والربط بالحضور والمأموريات والإجازات.",
  );

  const draw = () => {
    const filtered = filterEmployees(employees);
    app.querySelector("#employees-list").innerHTML = filtered.map((employee) => `
      <article class="person-card">
        ${avatar(employee)}
        <div class="person-main">
          <h3>${escapeHtml(employee.fullName)}</h3>
          <p>${escapeHtml(employee.jobTitle || "-")}</p>
          <div class="meta-row"><span>${escapeHtml(employee.phone || "-")}</span><span>${escapeHtml(employee.email || "-")}</span></div>
          <div class="meta-row"><span>${escapeHtml(employee.branch?.name || "-")}</span><span>${escapeHtml(employee.department?.name || "-")}</span><span>${escapeHtml(employee.role?.name || "-")}</span></div>
        </div>
        <div class="person-actions">
          ${badge(employee.status)}
          <button class="button ghost" data-view="${employee.id}">عرض</button>
          <button class="button ghost" data-edit="${employee.id}">تعديل</button>
          <button class="button ghost" data-toggle="${employee.id}">${employee.status === "ACTIVE" ? "تعطيل" : "تنشيط"}</button>
          <button class="button danger ghost" data-delete="${employee.id}">حذف منطقي</button>
        </div>
      </article>
    `).join("") || `<div class="empty-box">لا توجد نتائج مطابقة.</div>`;
    bindEmployeeActions(ref);
  };

  app.querySelector("#employee-filters").addEventListener("input", draw);
  app.querySelector('[data-action="new-employee"]').addEventListener("click", () => showEmployeeEditor(ref));
  draw();
}

function bindEmployeeActions(ref) {
  app.querySelectorAll("[data-view]").forEach((button) => button.addEventListener("click", () => (location.hash = `employee-profile?id=${button.dataset.view}`)));
  app.querySelectorAll("[data-edit]").forEach((button) => button.addEventListener("click", async () => showEmployeeEditor(ref, await endpoints.employee(button.dataset.edit))));
  app.querySelectorAll("[data-toggle]").forEach((button) => button.addEventListener("click", async () => {
    const employee = await endpoints.employee(button.dataset.toggle);
    await endpoints.setEmployeeStatus(button.dataset.toggle, employee.status === "ACTIVE" ? "SUSPENDED" : "ACTIVE");
    setMessage("تم تحديث حالة الموظف.", "");
    render();
  }));
  app.querySelectorAll("[data-delete]").forEach((button) => button.addEventListener("click", async () => {
    await endpoints.deleteEmployee(button.dataset.delete);
    setMessage("تم حذف الموظف منطقيًا وتعطيل حسابه المرتبط إن وجد.", "");
    render();
  }));
}

function showEmployeeEditor(ref, employee = null) {
  const editor = app.querySelector("#employee-editor");
  const managerOptions = ref.employees.filter((item) => item.id !== employee?.id).map((item) => ({ id: item.id, name: item.fullName }));
  editor.classList.remove("hidden");
  editor.innerHTML = `
    <div class="panel-head"><h2>${employee ? "تعديل موظف" : "إضافة موظف جديد"}</h2><button class="button ghost" data-close-editor>إغلاق</button></div>
    <form id="employee-form" class="editor-grid">
      <div class="photo-box">
        <div id="photo-preview">${avatar(employee || { fullName: "موظف جديد" })}</div>
        <label>الصورة الشخصية<input name="photo" type="file" accept="image/*" /></label>
      </div>
      <label>الاسم الكامل<input name="fullName" required value="${escapeHtml(employee?.fullName || "")}" /></label>
      <label>رقم الموبايل<input name="phone" value="${escapeHtml(employee?.phone || "")}" /></label>
      <label>البريد الإلكتروني<input name="email" type="email" value="${escapeHtml(employee?.email || "")}" /></label>
      <label>كود الموظف<input name="employeeCode" required value="${escapeHtml(employee?.employeeCode || "")}" /></label>
      <label>المسمى الوظيفي<input name="jobTitle" value="${escapeHtml(employee?.jobTitle || "")}" /></label>
      <label>الدور<select name="roleId">${optionList(ref.roles, employee?.roleId)}</select></label>
      <label>الفرع<select name="branchId">${optionList(ref.branches, employee?.branchId)}</select></label>
      <label>القسم<select name="departmentId">${optionList(ref.departments, employee?.departmentId)}</select></label>
      <label>المحافظة<select name="governorateId">${optionList(ref.governorates, employee?.governorateId)}</select></label>
      <label>المجمع<select name="complexId">${optionList(ref.complexes, employee?.complexId)}</select></label>
      <label>المدير المباشر<select name="managerEmployeeId">${optionList(managerOptions, employee?.managerEmployeeId, "بدون")}</select></label>
      <label>الحالة<select name="status">${optionList([{ id: "ACTIVE", name: "نشط" }, { id: "SUSPENDED", name: "موقوف" }, { id: "ON_LEAVE", name: "إجازة" }, { id: "INACTIVE", name: "غير مفعل" }], employee?.status || "ACTIVE")}</select></label>
      ${employee ? "" : `<label class="check-row"><input type="checkbox" name="createUser" checked /> إنشاء حساب مستخدم مرتبط</label><label>كلمة مرور مؤقتة<input name="password" value="Temp@123" /></label>`}
      <div class="form-actions wide"><button class="button primary" type="submit">حفظ الملف</button></div>
    </form>
  `;
  editor.scrollIntoView({ behavior: "smooth", block: "start" });
  const photoInput = editor.querySelector('[name="photo"]');
  photoInput.addEventListener("change", async () => {
    const photoUrl = await readPhoto(photoInput);
    editor.querySelector("#photo-preview").innerHTML = `<img class="avatar large" src="${photoUrl}" alt="" />`;
  });
  editor.querySelector("[data-close-editor]").addEventListener("click", () => editor.classList.add("hidden"));
  editor.querySelector("#employee-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const values = readForm(event.currentTarget);
      values.photoUrl = await readPhoto(photoInput) || employee?.photoUrl || "";
      if (employee) await endpoints.updateEmployee(employee.id, values);
      else await endpoints.createEmployee(values);
      setMessage(employee ? "تم تعديل ملف الموظف." : "تم إنشاء ملف الموظف وحسابه عند الطلب.", "");
      render();
    } catch (error) {
      setMessage("", error.message);
      render();
    }
  });
}

async function renderEmployeeProfile() {
  const employee = await endpoints.employee(routeParams().get("id"));
  shell(
    `<section class="profile-layout">
      <article class="panel profile-card">
        ${avatar(employee, "large")}
        <h2>${escapeHtml(employee.fullName)}</h2>
        <p>${escapeHtml(employee.jobTitle || "-")}</p>
        ${badge(employee.status)}
        <div class="profile-actions"><button class="button" data-route="employees">رجوع للقائمة</button></div>
      </article>
      <article class="panel profile-details">
        <div class="panel-head"><h2>البيانات الأساسية</h2><span>${escapeHtml(employee.employeeCode)}</span></div>
        ${table(["البند", "القيمة"], [
          ["الهاتف", employee.phone],
          ["البريد", employee.email],
          ["الدور", employee.role?.name],
          ["الفرع", employee.branch?.name],
          ["القسم", employee.department?.name],
          ["المحافظة", employee.governorate?.name],
          ["المجمع", employee.complex?.name],
          ["المدير المباشر", employee.manager?.fullName],
          ["حساب المستخدم", employee.user ? employee.user.email : "غير مرتبط"],
        ].map(([key, value]) => `<tr><td>${escapeHtml(key)}</td><td>${escapeHtml(value || "-")}</td></tr>`))}
      </article>
      <article class="panel span-4"><h2>الحضور</h2>${table(["النوع", "الوقت"], employee.attendanceEvents.map((item) => `<tr><td>${badge(item.type)}</td><td>${date(item.eventAt)}</td></tr>`))}</article>
      <article class="panel span-4"><h2>المأموريات</h2>${table(["العنوان", "الحالة"], employee.missions.map((item) => `<tr><td>${escapeHtml(item.title)}</td><td>${badge(item.status)}</td></tr>`))}</article>
      <article class="panel span-4"><h2>الإجازات</h2>${table(["النوع", "الحالة"], employee.leaves.map((item) => `<tr><td>${escapeHtml(item.leaveType?.name)}</td><td>${badge(item.status)}</td></tr>`))}</article>
    </section>`,
    "ملف الموظف",
    "عرض مترابط للبيانات الأساسية والتشغيلية.",
  );
}

async function renderUsers() {
  const [users, ref] = await Promise.all([endpoints.users().then(unwrap), referenceData()]);
  shell(
    `<section class="stack">
      <article class="panel">
        <div class="panel-head"><div><h2>إدارة المستخدمين</h2><p>إنشاء وتعديل وتعطيل الحسابات وربطها بالموظفين والأدوار.</p></div><button class="button primary" data-new-user>إضافة مستخدم</button></div>
        <form class="filters" id="user-filters"><input name="q" placeholder="بحث بالاسم أو البريد" /><select name="roleId">${optionList(ref.roles, "", "كل الأدوار")}</select><select name="status">${optionList([{ id: "ACTIVE", name: "نشط" }, { id: "DISABLED", name: "معطل" }], "", "كل الحالات")}</select></form>
        <div id="users-table"></div>
      </article>
      <article id="user-editor" class="panel hidden"></article>
    </section>`,
    "المستخدمون",
    "إدارة حسابات الدخول مع كلمة مرور مؤقتة ودعم passkey كحالة محفوظة.",
  );
  const draw = () => {
    const values = readForm(app.querySelector("#user-filters"));
    const q = (values.q || "").toLowerCase();
    const filtered = users.filter((user) => (!q || [user.name, user.email].join(" ").toLowerCase().includes(q)) && (!values.roleId || user.roleId === values.roleId) && (!values.status || user.status === values.status));
    app.querySelector("#users-table").innerHTML = table(["المستخدم", "الدور", "الموظف", "النطاق", "آخر دخول", "الحالة", "إجراءات"], filtered.map((user) => `
      <tr>
        <td class="person-cell">${avatar(user.employee || user, "tiny")}<span>${escapeHtml(user.name)}<small>${escapeHtml(user.email)}</small></span></td>
        <td>${escapeHtml(user.role?.name || "-")}</td>
        <td>${escapeHtml(user.employee?.fullName || "غير مرتبط")}</td>
        <td>${escapeHtml(user.branch?.name || "-")} / ${escapeHtml(user.department?.name || "-")}</td>
        <td>${date(user.lastLoginAt)}</td>
        <td>${badge(user.status)} ${user.temporaryPassword ? badge("PENDING") : ""}</td>
        <td><button class="button ghost" data-edit-user="${user.id}">تعديل</button><button class="button ghost" data-toggle-user="${user.id}">${user.status === "ACTIVE" ? "تعطيل" : "تنشيط"}</button></td>
      </tr>`));
    bindUserActions(ref);
  };
  app.querySelector("#user-filters").addEventListener("input", draw);
  app.querySelector("[data-new-user]").addEventListener("click", () => showUserEditor(ref));
  draw();
}

function bindUserActions(ref) {
  app.querySelectorAll("[data-edit-user]").forEach((button) => button.addEventListener("click", async () => {
    const users = await endpoints.users();
    showUserEditor(ref, users.find((user) => user.id === button.dataset.editUser));
  }));
  app.querySelectorAll("[data-toggle-user]").forEach((button) => button.addEventListener("click", async () => {
    const users = await endpoints.users();
    const user = users.find((item) => item.id === button.dataset.toggleUser);
    await endpoints.setUserStatus(user.id, user.status === "ACTIVE" ? "DISABLED" : "ACTIVE");
    setMessage("تم تحديث حالة المستخدم.", "");
    render();
  }));
}

function showUserEditor(ref, user = null) {
  const editor = app.querySelector("#user-editor");
  editor.classList.remove("hidden");
  editor.innerHTML = `
    <div class="panel-head"><h2>${user ? "تعديل مستخدم" : "إضافة مستخدم"}</h2><button class="button ghost" data-close-user>إغلاق</button></div>
    <form id="user-form" class="editor-grid">
      <label>الاسم<input name="name" required value="${escapeHtml(user?.name || "")}" /></label>
      <label>البريد<input name="email" type="email" required value="${escapeHtml(user?.email || "")}" /></label>
      <label>كلمة المرور المؤقتة<input name="password" value="" placeholder="${user ? "اتركه فارغًا للإبقاء عليها" : "Temp@123"}" /></label>
      <label>الموظف المرتبط<select name="employeeId">${optionList(ref.employees.map((employee) => ({ id: employee.id, name: `${employee.employeeCode} - ${employee.fullName}` })), user?.employeeId, "بدون")}</select></label>
      <label>الدور<select name="roleId">${optionList(ref.roles, user?.roleId)}</select></label>
      <label>الفرع<select name="branchId">${optionList(ref.branches, user?.branchId, "بدون")}</select></label>
      <label>القسم<select name="departmentId">${optionList(ref.departments, user?.departmentId, "بدون")}</select></label>
      <label>المحافظة<select name="governorateId">${optionList(ref.governorates, user?.governorateId, "بدون")}</select></label>
      <label>المجمع<select name="complexId">${optionList(ref.complexes, user?.complexId, "بدون")}</select></label>
      <label>الحالة<select name="status">${optionList([{ id: "ACTIVE", name: "نشط" }, { id: "DISABLED", name: "معطل" }], user?.status || "ACTIVE")}</select></label>
      <label class="check-row"><input type="checkbox" name="temporaryPassword" ${user?.temporaryPassword ?? true ? "checked" : ""} /> كلمة مرور مؤقتة</label>
      <label class="check-row"><input type="checkbox" name="passkeyEnabled" ${user?.passkeyEnabled ? "checked" : ""} /> Passkey مفعلة</label>
      <div class="form-actions wide"><button class="button primary" type="submit">حفظ المستخدم</button></div>
    </form>
  `;
  editor.scrollIntoView({ behavior: "smooth", block: "start" });
  editor.querySelector("[data-close-user]").addEventListener("click", () => editor.classList.add("hidden"));
  editor.querySelector("#user-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const values = readForm(event.currentTarget);
      if (!values.password) delete values.password;
      if (user) await endpoints.updateUser(user.id, values);
      else await endpoints.createUser(values);
      setMessage(user ? "تم تعديل المستخدم." : "تم إنشاء المستخدم.", "");
      render();
    } catch (error) {
      setMessage("", error.message);
      render();
    }
  });
}

async function renderAttendance() {
  const [employees, events] = await Promise.all([endpoints.employees().then(unwrap), endpoints.attendanceEvents().then(unwrap)]);
  const employeeSelect = optionList(employees.map((employee) => ({ id: employee.id, name: `${employee.employeeCode} - ${employee.fullName}` })));
  shell(
    `<section class="grid">
      <article class="panel span-4">
        <div class="panel-head"><div><h2>تسجيل سريع</h2><p>يسجل الحركة مع الموقع الجغرافي وحالة التحقق.</p></div></div>
        <label>الموظف<select id="attendance-employee">${employeeSelect}</select></label>
        <label>ملاحظات<input id="attendance-notes" placeholder="اختياري: سبب أو توضيح" /></label>
        <label>حالة التحقق<select id="attendance-verification"><option value="verified">تم التحقق من الجهاز</option><option value="not_checked">بدون تحقق</option><option value="failed">فشل التحقق</option></select></label>
        <div class="toolbar spaced"><button class="button primary" data-attendance="checkIn">حضور</button><button class="button" data-attendance="checkOut">انصراف</button></div>
        <div id="attendance-result" class="risk-box hidden"></div>
      </article>
      <article class="panel span-8">
        <h2>سجل الحضور</h2>
        ${table(["الموظف", "النوع", "الموقع", "المراجعة", "المخاطر", "الوقت"], events.map((event) => `<tr><td class="person-cell">${avatar(event.employee, "tiny")}<span>${escapeHtml(event.employee?.fullName || event.employeeId)}<small>${escapeHtml(event.notes || "")}</small></span></td><td>${badge(event.type)}</td><td>${badge(event.geofenceStatus || "unknown")}<small>${event.distanceFromBranchMeters != null ? `${event.distanceFromBranchMeters} متر` : ""}</small></td><td>${event.requiresReview ? badge("PENDING") : badge("APPROVED")}</td><td>${(event.riskFlags || []).length ? event.riskFlags.map((flag) => `<span class="status">${escapeHtml(flag)}</span>`).join(" ") : `<span class="status ACTIVE">آمن</span>`}</td><td>${date(event.eventAt)}</td></tr>`))}
      </article>
    </section>`,
    "الحضور",
    "تسجيل ومراجعة أحداث الحضور مع تقييم الموقع الجغرافي وحالة المراجعة.",
  );
  const recordAttendance = async (action) => {
    const resultBox = app.querySelector("#attendance-result");
    resultBox.classList.remove("hidden");
    resultBox.textContent = "جاري قراءة الموقع وتقييم الحركة...";
    const location = await getBrowserLocation();
    const body = {
      employeeId: app.querySelector("#attendance-employee").value,
      notes: app.querySelector("#attendance-notes").value,
      verificationStatus: app.querySelector("#attendance-verification").value,
      ...location,
    };
    const response = action === "checkIn" ? await endpoints.checkIn(body) : await endpoints.checkOut(body);
    const evaluation = response.evaluation || {};
    resultBox.innerHTML = `
      <strong>${evaluation.requiresReview ? "الحركة تحتاج مراجعة" : "الحركة مقبولة"}</strong>
      <div class="toolbar spaced">
        ${badge(evaluation.type)}
        ${badge(evaluation.geofenceStatus)}
        ${badge(evaluation.verificationStatus)}
      </div>
      <p>${evaluation.distanceFromBranchMeters != null ? `المسافة عن الفرع: ${evaluation.distanceFromBranchMeters} متر.` : "لم يتم حساب المسافة."}</p>
      ${(evaluation.riskFlags || []).length ? `<p>المخاطر: ${evaluation.riskFlags.map(escapeHtml).join("، ")}</p>` : `<p>لا توجد مخاطر مسجلة.</p>`}
    `;
    setMessage(action === "checkIn" ? "تم تسجيل الحضور مع تقييم الموقع." : "تم تسجيل الانصراف مع تقييم الموقع.", "");
    window.setTimeout(render, 1200);
  };
  app.querySelector('[data-attendance="checkIn"]').addEventListener("click", () => recordAttendance("checkIn"));
  app.querySelector('[data-attendance="checkOut"]').addEventListener("click", () => recordAttendance("checkOut"));
}

async function renderMissions() {
  const [employees, missions] = await Promise.all([endpoints.employees().then(unwrap), endpoints.missions().then(unwrap)]);
  const employeeSelect = optionList(employees.map((employee) => ({ id: employee.id, name: `${employee.employeeCode} - ${employee.fullName}` })));
  shell(
    `<section class="grid">
      <article class="panel span-4"><h2>مأمورية جديدة</h2>${simpleForm("mission-form", [["employeeId", "الموظف", "select", employeeSelect], ["title", "العنوان"], ["destinationName", "الوجهة"], ["plannedStart", "البداية", "datetime-local"], ["plannedEnd", "النهاية", "datetime-local"]], "إنشاء")}</article>
      <article class="panel span-8"><h2>المأموريات</h2>${table(["العنوان", "الموظف", "الوجهة", "الحالة", "إجراءات"], missions.map((mission) => `<tr><td>${escapeHtml(mission.title)}</td><td>${escapeHtml(mission.employee?.fullName || "-")}</td><td>${escapeHtml(mission.destinationName)}</td><td>${badge(mission.status)}</td><td><button class="button ghost" data-mission="${mission.id}" data-action-name="approve">اعتماد</button><button class="button ghost" data-mission="${mission.id}" data-action-name="complete">إكمال</button></td></tr>`))}</article>
    </section>`,
    "المأموريات",
    "تدفق بسيط لإنشاء واعتماد وإكمال المأموريات.",
  );
  app.querySelector("#mission-form").addEventListener("submit", submitForm(endpoints.createMission, "تم إنشاء المأمورية."));
  app.querySelectorAll("[data-mission]").forEach((button) => button.addEventListener("click", async () => {
    await endpoints.updateMission(button.dataset.mission, button.dataset.actionName);
    setMessage("تم تحديث المأمورية.", "");
    render();
  }));
}

async function renderLeaves() {
  const [employees, leaves] = await Promise.all([endpoints.employees().then(unwrap), endpoints.leaves().then(unwrap)]);
  const employeeSelect = optionList(employees.map((employee) => ({ id: employee.id, name: `${employee.employeeCode} - ${employee.fullName}` })));
  shell(
    `<section class="grid">
      <article class="panel span-4"><h2>طلب إجازة</h2>${simpleForm("leave-form", [["employeeId", "الموظف", "select", employeeSelect], ["leaveType", "نوع الإجازة", "select", optionList([{ name: "اعتيادية" }, { name: "مرضية" }, { name: "طارئة" }])], ["startDate", "من", "date"], ["endDate", "إلى", "date"], ["reason", "السبب"]], "إرسال")}</article>
      <article class="panel span-8"><h2>طلبات الإجازة</h2>${table(["الموظف", "النوع", "من", "إلى", "الحالة", "إجراءات"], leaves.map((leave) => `<tr><td>${escapeHtml(leave.employee?.fullName || "-")}</td><td>${escapeHtml(leave.leaveType?.name)}</td><td>${date(leave.startDate)}</td><td>${date(leave.endDate)}</td><td>${badge(leave.status)}</td><td><button class="button ghost" data-leave="${leave.id}" data-action-name="approve">اعتماد</button><button class="button danger ghost" data-leave="${leave.id}" data-action-name="reject">رفض</button></td></tr>`))}</article>
    </section>`,
    "الإجازات",
    "إرسال واعتماد ورفض طلبات الإجازة.",
  );
  app.querySelector("#leave-form").addEventListener("submit", submitForm(endpoints.createLeave, "تم إرسال طلب الإجازة."));
  app.querySelectorAll("[data-leave]").forEach((button) => button.addEventListener("click", async () => {
    await endpoints.updateLeave(button.dataset.leave, button.dataset.actionName);
    setMessage("تم تحديث طلب الإجازة.", "");
    render();
  }));
}

function simpleForm(id, fields, submitText) {
  return `<form id="${id}" class="form-grid compact-form">${fields.map(([name, label, type = "text", opts = ""]) => `<label>${escapeHtml(label)}${type === "select" ? `<select name="${name}">${opts}</select>` : `<input name="${name}" type="${type}" required />`}</label>`).join("")}<div class="form-actions"><button class="button primary" type="submit">${escapeHtml(submitText)}</button></div></form>`;
}

function submitForm(handler, successMessage) {
  return async (event) => {
    event.preventDefault();
    try {
      await handler(readForm(event.currentTarget));
      setMessage(successMessage, "");
      render();
    } catch (error) {
      setMessage("", error.message);
      render();
    }
  };
}

async function renderGeneric(title, description, loader) {
  const rows = unwrap(await loader());
  shell(
    `<section class="grid"><article class="panel"><h2>${escapeHtml(title)}</h2>${table(["المعرف", "العنوان/الاسم", "الموظف", "الحالة", "التاريخ"], rows.map((item) => `<tr><td>${escapeHtml(item.id || "-")}</td><td>${escapeHtml(item.title || item.name || item.fullName || item.key || "-")}</td><td>${escapeHtml(item.employee?.fullName || "-")}</td><td>${badge(item.status || item.type || "-")}</td><td>${date(item.createdAt || item.updatedAt || item.date)}</td></tr>`))}</article></section>`,
    title,
    description,
  );
}

async function renderReports() {
  const payload = await endpoints.reports();
  const jobs = payload.jobs || [];
  shell(
    `<section class="grid"><article class="panel span-4"><h2>طلب تقرير</h2>${simpleForm("report-form", [["title", "العنوان"], ["reportKey", "النوع"], ["format", "الصيغة"]], "إنشاء")}</article><article class="panel span-8"><div class="panel-head"><h2>التقارير</h2><button class="button ghost" id="export-csv">تحميل CSV</button></div>${table(["العنوان", "النوع", "الصيغة", "الحالة", "التاريخ"], jobs.map((job) => `<tr><td>${escapeHtml(job.title)}</td><td>${escapeHtml(job.reportKey)}</td><td>${escapeHtml(job.format)}</td><td>${badge(job.status)}</td><td>${date(job.createdAt)}</td></tr>`))}</article></section>`,
    "التقارير",
    "تقارير تشغيلية قابلة للتصدير من بيانات الحضور الحالية.",
  );
  app.querySelector("#report-form").addEventListener("submit", submitForm(endpoints.createReport, "تم إنشاء التقرير."));
  app.querySelector("#export-csv").addEventListener("click", exportAttendanceCsv);
}

async function renderSettings() {
  const [health, settings, queue] = await Promise.all([endpoints.health(), endpoints.settings().then(unwrap), endpoints.queue()]);
  shell(
    `<section class="grid">
      <article class="panel span-6"><h2>حالة التشغيل</h2>${table(["البند", "القيمة"], [`<tr><td>التطبيق</td><td>${escapeHtml(health.app)}</td></tr>`, `<tr><td>قاعدة البيانات</td><td>${escapeHtml(health.database.mode)} / متصلة</td></tr>`, `<tr><td>الجلسات</td><td>${health.authEnforced ? "مفعلة" : "اختيارية"}</td></tr>`, `<tr><td>Queue</td><td>${queue.enabled ? "مفعلة" : "غير مفعلة"}</td></tr>`])}</article>
      <article class="panel span-6"><h2>الإعدادات</h2>${table(["المفتاح", "القيمة", "النطاق"], settings.map((item) => `<tr><td>${escapeHtml(item.key)}</td><td>${escapeHtml(item.value)}</td><td>${escapeHtml(item.scope)}</td></tr>`))}</article>
    </section>`,
    "الإعدادات",
    "توضيح حدود التشغيل المحلي الحالي.",
  );
}

async function exportAttendanceCsv() {
  const events = await endpoints.attendanceEvents();
  const rows = [["employee", "type", "eventAt", "source"], ...events.map((event) => [event.employee?.fullName || event.employeeId, statusLabel(event.type), event.eventAt, event.source])];
  const csv = rows.map((row) => row.map((cell) => `"${String(cell ?? "").replaceAll('"', '""')}"`).join(",")).join("\n");
  const link = document.createElement("a");
  link.href = URL.createObjectURL(new Blob([`\ufeff${csv}`], { type: "text/csv;charset=utf-8" }));
  link.download = "attendance-report.csv";
  link.click();
  URL.revokeObjectURL(link.href);
}

async function render() {
  try {
    state.error = "";
    if (!state.user) state.user = await endpoints.me().then(unwrap).catch(() => null);
    if (!state.user && routeKey() !== "login") return renderLogin();

    const key = routeKey();
    if (key === "dashboard") await renderDashboard();
    else if (key === "employees") await renderEmployees();
    else if (key === "employee-profile") await renderEmployeeProfile();
    else if (key === "users") await renderUsers();
    else if (key === "attendance") await renderAttendance();
    else if (key === "missions") await renderMissions();
    else if (key === "leaves") await renderLeaves();
    else if (key === "reports") await renderReports();
    else if (key === "settings") await renderSettings();
    else if (key === "locations") await renderGeneric("المواقع", "سجل المواقع والطلبات المرتبطة بالموظفين.", endpoints.locations);
    else if (key === "kpi") await renderGeneric("مؤشرات الأداء", "مؤشرات محسوبة من بيانات الأشخاص والحسابات والطلبات.", endpoints.kpi);
    else if (key === "notifications") await renderGeneric("الإشعارات", "إشعارات النظام.", endpoints.notifications);
    else await renderDashboard();
  } catch (error) {
    setMessage("", error.message);
    shell(`<section class="panel"><h2>تعذر تحميل الصفحة</h2></section>`, "خطأ", "راجع بيانات المتصفح المحلية.");
  }
}

render();
