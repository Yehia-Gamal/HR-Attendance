export const seedDatabase = {
  roles: [
    { id: "role-admin", name: "مدير النظام", key: "ADMIN" },
    { id: "role-hr", name: "مدير موارد بشرية", key: "HR_MANAGER" },
    { id: "role-supervisor", name: "مشرف", key: "SUPERVISOR" },
    { id: "role-employee", name: "موظف", key: "EMPLOYEE" },
    { id: "role-finance", name: "حسابات", key: "FINANCE" },
  ],
  governorates: [
    { id: "gov-cairo", name: "القاهرة" },
    { id: "gov-giza", name: "الجيزة" },
    { id: "gov-alex", name: "الإسكندرية" },
  ],
  complexes: [
    { id: "cx-nasr", name: "مجمع مدينة نصر", governorateId: "gov-cairo" },
    { id: "cx-dokki", name: "مجمع الدقي", governorateId: "gov-giza" },
    { id: "cx-smouha", name: "مجمع سموحة", governorateId: "gov-alex" },
  ],
  branches: [
    { id: "b-cairo", name: "فرع القاهرة", governorateId: "gov-cairo", complexId: "cx-nasr", latitude: 30.0444, longitude: 31.2357, geofenceRadiusMeters: 250 },
    { id: "b-giza", name: "فرع الجيزة", governorateId: "gov-giza", complexId: "cx-dokki", latitude: 30.0386, longitude: 31.2118, geofenceRadiusMeters: 250 },
    { id: "b-alex", name: "فرع الإسكندرية", governorateId: "gov-alex", complexId: "cx-smouha", latitude: 31.2001, longitude: 29.9187, geofenceRadiusMeters: 300 },
  ],
  departments: [
    { id: "d-hr", name: "الموارد البشرية" },
    { id: "d-ops", name: "التشغيل" },
    { id: "d-sales", name: "المبيعات" },
    { id: "d-fin", name: "الحسابات" },
    { id: "d-it", name: "تقنية المعلومات" },
  ],
  employees: [
    { id: "emp-001", employeeCode: "HR-001", fullName: "أحمد محمد عبدالعزيز", phone: "01010000001", email: "ahmed.hr@company.local", photoUrl: "", jobTitle: "مدير موارد بشرية", roleId: "role-hr", branchId: "b-cairo", departmentId: "d-hr", governorateId: "gov-cairo", complexId: "cx-nasr", managerEmployeeId: "", status: "ACTIVE", isDeleted: false, hireDate: "2021-03-15", userId: "u-admin" },
    { id: "emp-002", employeeCode: "OP-014", fullName: "سارة علي حسن", phone: "01010000002", email: "sara.ops@company.local", photoUrl: "", jobTitle: "مشرفة تشغيل", roleId: "role-supervisor", branchId: "b-cairo", departmentId: "d-ops", governorateId: "gov-cairo", complexId: "cx-nasr", managerEmployeeId: "emp-001", status: "ACTIVE", isDeleted: false, hireDate: "2022-01-10", userId: "u-sara" },
    { id: "emp-003", employeeCode: "SL-022", fullName: "محمود خالد إبراهيم", phone: "01010000003", email: "mahmoud.sales@company.local", photoUrl: "", jobTitle: "مسؤول مبيعات", roleId: "role-employee", branchId: "b-giza", departmentId: "d-sales", governorateId: "gov-giza", complexId: "cx-dokki", managerEmployeeId: "emp-002", status: "ACTIVE", isDeleted: false, hireDate: "2020-09-01", userId: "u-mahmoud" },
    { id: "emp-004", employeeCode: "FN-008", fullName: "منى سامي يوسف", phone: "01010000004", email: "mona.fin@company.local", photoUrl: "", jobTitle: "محاسبة", roleId: "role-finance", branchId: "b-cairo", departmentId: "d-fin", governorateId: "gov-cairo", complexId: "cx-nasr", managerEmployeeId: "emp-001", status: "ON_LEAVE", isDeleted: false, hireDate: "2023-04-02", userId: "" },
    { id: "emp-005", employeeCode: "IT-011", fullName: "كريم وليد منصور", phone: "01010000005", email: "karim.it@company.local", photoUrl: "", jobTitle: "مهندس نظم", roleId: "role-supervisor", branchId: "b-giza", departmentId: "d-it", governorateId: "gov-giza", complexId: "cx-dokki", managerEmployeeId: "emp-001", status: "ACTIVE", isDeleted: false, hireDate: "2022-11-20", userId: "u-karim" },
    { id: "emp-006", employeeCode: "OP-018", fullName: "نورهان عادل فؤاد", phone: "01010000006", email: "nourhan.ops@company.local", photoUrl: "", jobTitle: "منسقة ورديات", roleId: "role-employee", branchId: "b-alex", departmentId: "d-ops", governorateId: "gov-alex", complexId: "cx-smouha", managerEmployeeId: "emp-002", status: "ACTIVE", isDeleted: false, hireDate: "2021-12-05", userId: "" },
    { id: "emp-007", employeeCode: "SL-029", fullName: "يوسف طارق نصر", phone: "01010000007", email: "youssef.sales@company.local", photoUrl: "", jobTitle: "مندوب مبيعات", roleId: "role-employee", branchId: "b-alex", departmentId: "d-sales", governorateId: "gov-alex", complexId: "cx-smouha", managerEmployeeId: "emp-003", status: "INACTIVE", isDeleted: false, hireDate: "2024-02-12", userId: "" },
    { id: "emp-008", employeeCode: "HR-006", fullName: "هبة مصطفى أمين", phone: "01010000008", email: "heba.hr@company.local", photoUrl: "", jobTitle: "أخصائية شؤون عاملين", roleId: "role-hr", branchId: "b-giza", departmentId: "d-hr", governorateId: "gov-giza", complexId: "cx-dokki", managerEmployeeId: "emp-001", status: "ACTIVE", isDeleted: false, hireDate: "2022-07-18", userId: "u-heba" },
    { id: "emp-009", employeeCode: "OP-031", fullName: "إسلام فتحي جابر", phone: "01010000009", email: "eslam.ops@company.local", photoUrl: "", jobTitle: "مشرف مخزن", roleId: "role-supervisor", branchId: "b-cairo", departmentId: "d-ops", governorateId: "gov-cairo", complexId: "cx-nasr", managerEmployeeId: "emp-002", status: "SUSPENDED", isDeleted: false, hireDate: "2019-05-22", userId: "" },
    { id: "emp-010", employeeCode: "FN-015", fullName: "دينا أشرف مراد", phone: "01010000010", email: "dina.fin@company.local", photoUrl: "", jobTitle: "مراجعة مالية", roleId: "role-finance", branchId: "b-alex", departmentId: "d-fin", governorateId: "gov-alex", complexId: "cx-smouha", managerEmployeeId: "emp-004", status: "ACTIVE", isDeleted: false, hireDate: "2023-08-01", userId: "" },
  ],
  users: [
    { id: "u-admin", employeeId: "emp-001", name: "مدير النظام", email: "admin@company.local", password: "admin123", roleId: "role-admin", branchId: "b-cairo", departmentId: "d-hr", governorateId: "gov-cairo", complexId: "cx-nasr", status: "ACTIVE", temporaryPassword: false, passkeyEnabled: true, lastLoginAt: "2026-04-26T09:15:00" },
    { id: "u-sara", employeeId: "emp-002", name: "سارة علي حسن", email: "sara.ops@company.local", password: "Temp@123", roleId: "role-supervisor", branchId: "b-cairo", departmentId: "d-ops", governorateId: "gov-cairo", complexId: "cx-nasr", status: "ACTIVE", temporaryPassword: true, passkeyEnabled: false, lastLoginAt: "2026-04-25T16:10:00" },
    { id: "u-mahmoud", employeeId: "emp-003", name: "محمود خالد إبراهيم", email: "mahmoud.sales@company.local", password: "Temp@123", roleId: "role-employee", branchId: "b-giza", departmentId: "d-sales", governorateId: "gov-giza", complexId: "cx-dokki", status: "ACTIVE", temporaryPassword: true, passkeyEnabled: false, lastLoginAt: "" },
    { id: "u-karim", employeeId: "emp-005", name: "كريم وليد منصور", email: "karim.it@company.local", password: "Temp@123", roleId: "role-supervisor", branchId: "b-giza", departmentId: "d-it", governorateId: "gov-giza", complexId: "cx-dokki", status: "ACTIVE", temporaryPassword: true, passkeyEnabled: true, lastLoginAt: "2026-04-24T11:40:00" },
    { id: "u-heba", employeeId: "emp-008", name: "هبة مصطفى أمين", email: "heba.hr@company.local", password: "Temp@123", roleId: "role-hr", branchId: "b-giza", departmentId: "d-hr", governorateId: "gov-giza", complexId: "cx-dokki", status: "ACTIVE", temporaryPassword: true, passkeyEnabled: false, lastLoginAt: "" },
  ],
  attendanceEvents: [
    { id: "att-001", employeeId: "emp-001", type: "PRESENT", eventAt: "2026-04-26T08:02:00", source: "جهاز البصمة" },
    { id: "att-002", employeeId: "emp-002", type: "PRESENT", eventAt: "2026-04-26T08:08:00", source: "تطبيق الويب" },
    { id: "att-003", employeeId: "emp-003", type: "LATE", eventAt: "2026-04-26T09:17:00", source: "جهاز البصمة" },
    { id: "att-004", employeeId: "emp-004", type: "PRESENT", eventAt: "2026-04-26T08:00:00", source: "تطبيق الويب" },
    { id: "att-005", employeeId: "emp-005", type: "MISSION", eventAt: "2026-04-26T08:30:00", source: "مأمورية" },
    { id: "att-006", employeeId: "emp-006", type: "PRESENT", eventAt: "2026-04-26T08:11:00", source: "جهاز البصمة" },
    { id: "att-007", employeeId: "emp-007", type: "ABSENT", eventAt: "2026-04-26T09:30:00", source: "النظام" },
  ],
  missions: [
    { id: "mis-001", employeeId: "emp-005", title: "صيانة شبكة فرع الجيزة", destinationName: "فرع الجيزة", plannedStart: "2026-04-26T09:00", plannedEnd: "2026-04-26T14:00", status: "APPROVED", createdAt: "2026-04-25T12:20:00" },
    { id: "mis-002", employeeId: "emp-003", title: "زيارة عميل رئيسي", destinationName: "مدينة نصر", plannedStart: "2026-04-27T10:00", plannedEnd: "2026-04-27T13:00", status: "PENDING", createdAt: "2026-04-26T10:10:00" },
  ],
  leaves: [
    { id: "lv-001", employeeId: "emp-008", leaveType: { name: "اعتيادية" }, startDate: "2026-04-28", endDate: "2026-04-30", reason: "ظروف عائلية", status: "PENDING", createdAt: "2026-04-24T11:00:00" },
    { id: "lv-002", employeeId: "emp-004", leaveType: { name: "مرضية" }, startDate: "2026-04-26", endDate: "2026-04-27", reason: "متابعة طبية", status: "APPROVED", createdAt: "2026-04-25T09:30:00" },
  ],
  exceptions: [
    { id: "exc-001", title: "تأخير بعذر", employeeId: "emp-003", status: "APPROVED", createdAt: "2026-04-26T09:40:00" },
    { id: "exc-002", title: "نسيان بصمة انصراف", employeeId: "emp-006", status: "PENDING", createdAt: "2026-04-25T18:10:00" },
  ],
  locations: [
    { id: "loc-001", name: "فرع القاهرة", employeeId: "emp-001", status: "ACTIVE", date: "2026-04-26T08:00:00" },
    { id: "loc-002", name: "فرع الجيزة", employeeId: "emp-005", status: "ACTIVE", date: "2026-04-26T08:30:00" },
    { id: "loc-003", name: "موقع عميل مدينة نصر", employeeId: "emp-003", status: "VISITED", date: "2026-04-26T11:15:00" },
  ],
  notifications: [
    { id: "not-001", title: "طلب إجازة جديد من هبة مصطفى", status: "UNREAD", createdAt: "2026-04-26T10:00:00" },
    { id: "not-002", title: "تقرير الحضور اليومي جاهز", status: "READ", createdAt: "2026-04-26T09:00:00" },
  ],
  reports: [
    { id: "rep-001", title: "تقرير حضور اليوم", reportKey: "attendance", format: "csv", status: "COMPLETED", createdAt: "2026-04-26T11:30:00" },
  ],
  settings: [
    { id: "set-001", key: "workday.start", value: "08:00", scope: "company" },
    { id: "set-002", key: "workday.end", value: "16:00", scope: "company" },
    { id: "set-003", key: "lateGraceMinutes", value: 15, scope: "attendance" },
  ],
};
