# HR Attendance - Live Server Static

هذه نسخة Static Web فقط تعمل مباشرة عبر Live Server.

## التشغيل
1. افتح المجلد في VS Code.
2. كليك يمين على `index.html`.
3. اختر `Open with Live Server`.

## بيانات الدخول
- البريد: `admin@company.local`
- كلمة المرور: `admin123`

## ملاحظات مهمة
- لا يوجد React.
- لا يوجد Next.
- لا يوجد Node.js.
- لا يوجد Express أو Prisma.
- لا يوجد `node_modules`.
- البيانات تحفظ داخل المتصفح باستخدام `localStorage`.
- لإعادة البيانات الأصلية استخدم زر `استرجاع البيانات` داخل الإعدادات.

## الملفات الأساسية
- `index.html`
- `assets/app.js`
- `assets/api.js`
- `assets/database.js`
- `assets/styles.css`
- `manifest.json`
- `sw.js`
